# ConnectIt MVP

A mobile-first marketplace landing/MVP for repair services, patient attendants, helpers and rentals.

## Run locally
Open `index.html` in a browser.

## Free deployment
### Netlify
1. Go to https://app.netlify.com/drop
2. Drag this folder (or its ZIP contents) onto the page.
3. Netlify will publish a free `netlify.app` URL.

### Vercel
1. Create a GitHub repository.
2. Upload `index.html`.
3. Import the repository at Vercel.
4. Deploy as a static site.

This version is a frontend MVP. Provider matching, authentication, database, payments and admin approval should be connected in phase 2.
